/** @file typo.c
 *
 * @brief Echos characters back with timing data.
 *
 * Links to libc.
 */

int main(int argc, char** argv)
{
	/* Add code here -- put your names at the top. */
	return 0;
}
