int forty = 40;
int three = 3;
