/*
Satvik Dhandhania
andrew id: sdhandha@andrew.cmu.edu
*/
#include<stdio.h>
int main()
{
  printf("Hello world!\n");
  return 0;
}
