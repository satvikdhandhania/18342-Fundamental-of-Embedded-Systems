/*
 Satvik Dhandhania
 andrew id : sdhandha@andrew.cmu.edu
*/
int add(int x, int y);

int sub(int x, int y);

int mul(int x, int y);

int cdiv(int x, int y);

int mod(int x, int y);

