void C_SWI_handler(int swi_num, unsigned *regs);
